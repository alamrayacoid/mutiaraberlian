<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class m_mutcat extends Model
{
    protected $table = 'm_mutcat';
    protected $primaryKey  = 'm_id';
    public $timestamps = false;
}
