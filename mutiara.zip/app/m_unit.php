<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class m_unit extends Model
{
  protected $table = 'm_unit';
  protected $primaryKey  = 'u_id';
  public $timestamps = false;
}
