<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class d_opname extends Model
{
    protected $table = 'd_opname';
    protected $primaryKey  = 'o_id';
    public $timestamps = false;

}
