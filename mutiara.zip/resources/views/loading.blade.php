<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Loading</title>
    <link rel="stylesheet" href="{{asset('assets/css/loading.css')}}">
</head>
<body style="text-align:center;">

<svg
   id="logo"
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="152.0567mm"
   height="175.13814mm"
   viewBox="0 0 152.05671 175.13814"
   version="1.1"
   id="svg8"
   inkscape:version="0.92.4 (5da689c313, 2019-01-14)"
   sodipodi:docname="line.svg">
  <defs
     id="defs2">
    <clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath966">
      <path
         d="m 366.81849,108.24596 a 32.417263,32.417263 0 0 1 34.87839,29.68922 32.417263,32.417263 0 0 1 -29.62601,34.93209 32.417263,32.417263 0 0 1 -34.98569,-29.56271 32.417263,32.417263 0 0 1 29.49931,-35.03916"
         sodipodi:open="true"
         sodipodi:end="4.6258556"
         sodipodi:start="4.6330987"
         sodipodi:ry="32.417263"
         sodipodi:rx="32.417263"
         sodipodi:cy="140.56137"
         sodipodi:cx="369.38617"
         sodipodi:type="arc"
         id="path968"
         style="opacity:1;fill:#2250a0;fill-opacity:1;stroke:none;stroke-width:2.4245069;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1" />
    </clipPath>
  </defs>
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.23083958"
     inkscape:cx="-540.17449"
     inkscape:cy="335.019"
     inkscape:document-units="mm"
     inkscape:current-layer="layer1"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:window-width="1366"
     inkscape:window-height="686"
     inkscape:window-x="0"
     inkscape:window-y="27"
     inkscape:window-maximized="1" />
  <metadata
     id="metadata5">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(-30.402023,-65.608986)">
    <g
       id="g1065"
       transform="translate(-18.338859,-8.0232487)" />
    <g
       id="g1072"
       transform="translate(-218.92007,-10.31561)">
      <path
         style="fill:none;fill-opacity:1;stroke:#000000;stroke-width:1.62037408;stroke-linecap:butt;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
         d="m 400.4266,124.9742 -31.11767,18.27803 -0.35221,47.36056 -40.57774,23.27897 0.17611,36.36085 72.01352,-41.65349 z"
         id="path1007"
         inkscape:connector-curvature="0"
         sodipodi:nodetypes="ccccccc" />
      <path
         sodipodi:nodetypes="ccccccc"
         inkscape:connector-curvature="0"
         id="path1013"
         d="m 250.27429,124.59564 31.11767,18.27803 0.35222,47.36056 40.57773,23.27897 -0.17611,36.36085 -72.01352,-41.65349 z"
         style="fill:none;fill-opacity:1;stroke:#000000;stroke-width:1.62037408;stroke-linecap:butt;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <path
         sodipodi:nodetypes="ccccccc"
         inkscape:connector-curvature="0"
         id="path1015"
         d="m 252.9478,118.24068 31.28196,17.99539 41.32938,-23.13071 40.30904,23.74119 31.50947,-18.14651 -71.83228,-41.96527 z"
         style="fill:none;fill-opacity:1;stroke:#000000;stroke-width:1.62037408;stroke-linecap:butt;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1" />
      <path
         style="opacity:1;fill:none;fill-opacity:1;stroke:#000000;stroke-width:1.73448479;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1"
         id="path1017"
         sodipodi:type="arc"
         sodipodi:cx="326.14169"
         sodipodi:cy="163.21257"
         sodipodi:rx="23.19121"
         sodipodi:ry="23.19121"
         sodipodi:start="4.6330987"
         sodipodi:end="4.6258556"
         sodipodi:open="true"
         d="m 324.30478,140.09422 a 23.19121,23.19121 0 0 1 24.9519,21.23958 23.19121,23.19121 0 0 1 -21.19436,24.99031 23.19121,23.19121 0 0 1 -25.02865,-21.14907 23.19121,23.19121 0 0 1 21.10371,-25.06691" />
      <path
         style="fill:none;fill-opacity:1;stroke:none;stroke-width:1.62037408;stroke-linecap:butt;stroke-linejoin:round;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
         d="m 250.27429,124.59564 31.11767,18.27803 0.35222,47.36056 40.57773,23.27897 -0.17611,36.36085 -72.01352,-41.65349 z"
         id="path1021"
         inkscape:connector-curvature="0"
         sodipodi:nodetypes="ccccccc" />
    </g>
  </g>
</svg>

<svg aria-hidden="true" focusable="false" style="width:0;height:0;position:absolute;">
    <linearGradient id="gradient-vertical1" x2="0" y2="1">
        <stop offset="0%" stop-color="var(--color-stop-1)" />
        <stop offset="90%" stop-color="var(--color-stop-2)" />
        <stop offset="100%" stop-color="var(--color-stop-3)" />
    </linearGradient>
</svg>

<svg aria-hidden="true" focusable="false" style="width:0;height:0;position:absolute;">
    <linearGradient id="gradient-vertical2" x2="0" y2="1">
        <stop offset="45%" stop-color="var(--color-stop-1)" />
        <stop offset="90%" stop-color="var(--color-stop-2)" />
        <stop offset="100%" stop-color="var(--color-stop-3)" />
    </linearGradient>
</svg>

<svg aria-hidden="true" focusable="false" style="width:0;height:0;position:absolute;">
    <linearGradient id="gradient-horizontal3">
        <stop offset="0%" stop-color="var(--color-stop-1)" />
        <stop offset="50%" stop-color="var(--color-stop-2)" />
        <stop offset="100%" stop-color="var(--color-stop-3)" />
    </linearGradient>
</svg>

<svg aria-hidden="true" focusable="false" style="width:0;height:0;position:absolute;">
    <linearGradient id="gradient-vertical4" x2="0" y2="1">
        <stop offset="0%" stop-color="var(--color-stop-1)" />
        <stop offset="90%" stop-color="var(--color-stop-2)" />
        <stop offset="100%" stop-color="var(--color-stop-3)" />
    </linearGradient>
</svg>

<div>
   <img src="{{asset('assets/img/loading-text.png')}}" alt="" id="loading-text">
</div>

<div class="loader"></div>

<script src="{{asset('assets/js/loading.js')}}"></script>
</body>
</html>
