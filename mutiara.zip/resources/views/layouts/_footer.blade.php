<footer class="footer">
    <div class="footer-block author">
        <ul>
            <li>
              Copyright &copy; {{date('Y')}}
            </li>
            <li> 
                <a target="_blank" href="https://alamaraya.co.id">Alamraya Sebar Barokah</a>
            </li>
            <li>All rights reserved.</li>
        </ul>
    </div>
</footer>