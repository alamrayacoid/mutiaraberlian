var primaryColor   = '#33b5e5';
var secondaryColor = '#ffbb33';